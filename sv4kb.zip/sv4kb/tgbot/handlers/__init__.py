# - *- coding: utf- 8 - *-
from .main_errors import dp
from .main_start import dp
from .admin_menu import dp
from .user_menu import dp
from .user_transactions import dp
from .admin_functions import dp
from .admin_payment import dp
from .admin_products import dp
from .admin_settings import dp
from .main_missed_ import dp

__all__ = ['dp']
